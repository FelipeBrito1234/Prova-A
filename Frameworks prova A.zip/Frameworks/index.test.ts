import{test,expect} from 'vitest'

//Exercício 01 Explique o que é um componente em React e como criar um componente utilizando TypeScript. 
//R: É uma função do JavaScript/TypeScript que tem um retorno de JSX.

function Header(){
	return (<h1>Header<h1>)
}

//Exercício 02 Quais são as vantagens de utilizar TypeScript ao invés de JavaScript?
//R: A vantagem é que você transorma o JavaScript que é uma linguagem não tipada em uma linguagem tipada com o TypeScript.

/**
 * Exercício 03 - Contagem de vogais
 * Nome da função - contaVogais
 * Crie uma função que receba uma string e retorne a quantidade de vogais presentes na string.
 * @param {string} str A string que será analisada
 * @returns {number} Retorna a quantidade de vogais na string
 * @example
 * contaVogais("hello") // 2
 * contaVogais("abcdef") // 2
 */

// Início do seu código
function contaVogais(str:string) {
    let contador = 0
    for(let i=0;i<str.length;i++){
        if(str[i]=="a"||str[i]=="e"||str[i]=="i"||str[i]=="o"||str[i]=="u"||str[i]=="A"||str[i]=="E"||str[i]=="I"||str[i]=="O"||str[i]=="U"){
            contador++
        }
    }
    return contador
}
// Fim do seu código

test('contaVogais', () => {
    expect(contaVogais("hello")).toBe(2);
    expect(contaVogais("abcdef")).toBe(2);
    expect(contaVogais("xyz")).toBe(0);
    expect(contaVogais("AEIOU")).toBe(5);
});

/**
 * Exercício 04 - divisivelPor7Ou9
 * Nome da função - divisivelPor7Ou9
 * Crie uma função que retorna um array com os números divisíveis por 7 ou por 9 no intervalo
 * @param {number} min Número mínimo
 * @param {number} max Número máximo
 * @returns {number[]} Retorna um array com os números divisíveis por 7 ou por 9 no intervalo
 * @example
 * divisivelPor7Ou9(1, 50) // [7, 9, 14, 18, 21, 27, 28, 35, 36, 42, 45, 49]
 * divisivelPor7Ou9(7, 70) // [7, 9, 14, 18, 21, 27, 28, 35, 36, 42, 45, 49, 54, 56, 63, 70]
 */

//Início do seu código
function divisivelPor7Ou9(a:number,b:number):number[]{
    const divisores:number[] = []
    for(let i = a;i<=b;i++){
        if(i%7==0||i%9==0){
            divisores.push(i)
        }
    }
    return divisores

}
//Fim do seu código

test('divisivelPor7Ou9', () => {
    expect(divisivelPor7Ou9(1, 50)).toEqual([7, 9, 14, 18, 21, 27, 28, 35, 36, 42, 45, 49])
})
test("divisivelPor7Ou9 quando min = 7 e max = 70", () => {
    expect(divisivelPor7Ou9(7, 70)).toEqual([7, 9, 14, 18, 21, 27, 28, 35, 36, 42, 45, 49, 54, 56, 63, 70])
})
test('divisivelPor7Ou9 quando valores trocados', () => {
    expect(divisivelPor7Ou9(50, 1)).toEqual([])
})

/**
 * Exercício 05 - resolveEquacao2
 * Nome da função - resolveEquacao2
 * Crie uma função que retorne os pontos em Y a partir de um vetor dos pontos em X da equação y = x^4 + 3x^2 - x + 2
 * @param {number[]} vetor Vetor de pontos em X
 * @returns {number[]} Retorna um array com os pontos em Y
 * @example
 * resolveEquacao2([1, 2, 3]) // [4, 12, 26]
 */

//Início do seu código
function resolveEquacao2(v:number[]){
    const retorno:number[] = []
    for(let i=0;i<v.length;i++){
        let x = v[i]
        retorno.push(x**4 + 3*x**2 -x + 2)
    }
    return retorno
}

//Fim do seu código

test('resolveEquacao2', () => {
    expect(resolveEquacao2([1, 2, 3])).toEqual([5, 28, 107])
})
test('resolveEquacao2 quando números negativos', () => {
    expect(resolveEquacao2([-1, -2, -3, -4])).toEqual([7, 32, 113, 310])
})


/**
 * Exercício 06 - Crie testes para a função saudacao e explique o que é um teste.
 * Nome da função - saudacao
 * @returns {string} Retorna "Olá, Mundo!"
 * @example
 * saudacao() // "Olá, Mundo!"
 */
function saudacao(): string {
    return 'Olá, Mundo!'
}

//Início do seu código
test("Teste da função saudacao",()=>{
    expect(saudacao()).toBe('Olá, Mundo!')
})

// Teste é uma ferramenta automatizada para verificar a funcionalidade de códigos.
//Fim do seu código
